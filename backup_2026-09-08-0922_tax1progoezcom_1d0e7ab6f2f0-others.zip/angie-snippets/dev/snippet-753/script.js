class WooCarouselHandler extends elementorModules.frontend.handlers.Base {
    getDefaultSettings() {
        return {
            selectors: {
                container: '.woo-carousel-wrapper-6f187485'
            }
        };
    }

    getDefaultElements() {
        const selectors = this.getSettings('selectors');
        return {
            $container: this.$element.find(selectors.container)
        };
    }

    onInit() {
        super.onInit();
        this.initSwiper();
    }

    initSwiper() {
        const $container = this.elements.$container;
        if (!$container.length) return;

        new Swiper($container[0], {
            slidesPerView: 1,
            spaceBetween: 20,
            loop: true,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                640: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 4,
                }
            }
        });
    }
}

jQuery(window).on('elementor/frontend/init', () => {
    const addHandler = ($element) => {
        elementorFrontend.elementsHandler.addHandler(WooCarouselHandler, { $element });
    };
    elementorFrontend.hooks.addAction('frontend/element_ready/woo_carousel_6f187485.default', addHandler);
});
