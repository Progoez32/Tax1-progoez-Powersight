<?php

namespace AngieSnippets;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Woo_Carousel_6f187485 extends \Elementor\Widget_Base {
    public function get_name() { return 'woo_carousel_6f187485'; }
    public function get_title() { return esc_html__( 'Woo Custom Carousel', 'angie-snippets' ); }
    public function get_icon() { return 'eicon-carousel'; }
    public function get_categories() { return [ 'angie-widgets', 'general' ]; }
    public function get_script_depends() { return [ 'woo-carousel-script-6f187485' ]; }
    public function get_style_depends() { return [ 'woo-carousel-style-6f187485' ]; }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'Products Query', 'angie-snippets' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__( 'Number of Products', 'angie-snippets' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 8,
            ]
        );

        $this->add_control(
            'product_badge_text',
            [
                'label' => esc_html__( 'Card Badge Text', 'angie-snippets' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'TOP ANALYZER',
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'section_style_cards',
            [
                'label' => esc_html__( 'Card Styles', 'angie-snippets' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'brand_label_color',
            [
                'label' => esc_html__( 'Brand Label Color', 'angie-snippets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#7F8C8D',
                'selectors' => [
                    '{{WRAPPER}} .wc-brand-6f187485' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'angie-snippets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#E63946',
                'selectors' => [
                    '{{WRAPPER}} .wc-title-6f187485' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'primary_button_bg',
            [
                'label' => esc_html__( 'Button Background', 'angie-snippets' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#B22222',
                'selectors' => [
                    '{{WRAPPER}} .wc-btn-primary-6f187485' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            echo '<p>WooCommerce is not active.</p>';
            return;
        }

        $settings = $this->get_settings_for_display();

        $args = [
            'post_type' => 'product',
            'posts_per_page' => intval( $settings['posts_per_page'] ),
        ];

        $query = new \WP_Query( $args );

        if ( ! $query->have_posts() ) {
            echo '<p>No products found.</p>';
            return;
        }
        ?>
        <div class="woo-carousel-wrapper-6f187485 swiper-container">
            <div class="swiper-wrapper">
                <?php while ( $query->have_posts() ) : $query->the_post(); 
                    global $product;
                    if ( ! $product ) { continue; }
                    $image_url = wp_get_attachment_image_url( $product->get_image_id(), 'medium' );
                    $is_in_stock = $product->is_in_stock();
                    $regular_price = $product->get_regular_price();
                    $sale_price = $product->get_sale_price();
                    $savings = 0;
                    if ( $sale_price && $regular_price > $sale_price ) {
                        $savings = $regular_price - $sale_price;
                    }
                ?>
                    <div class="swiper-slide">
                        <div class="wc-card-6f187485">
                            <!-- Badges -->
                            <div class="wc-top-bar-6f187485">
                                <span class="wc-badge-6f187485"><?php echo esc_html( $settings['product_badge_text'] ); ?></span>
                                <span class="wc-stock-6f187485">
                                    <?php if ( $is_in_stock ) : ?>
                                        <span class="stock-green-6f187485">✓ In Stock</span>
                                    <?php else : ?>
                                        <span class="stock-red-6f187485">Out of Stock</span>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <!-- Image -->
                            <div class="wc-image-container-6f187485">
                                <img src="<?php echo esc_url( $image_url ? $image_url : wc_placeholder_img_src() ); ?>" alt="<?php the_title_attribute(); ?>">
                            </div>

                            <!-- Content -->
                            <div class="wc-content-6f187485">
                                <div class="wc-brand-6f187485">POWERSIGHT</div>
                                <h3 class="wc-title-6f187485"><?php the_title(); ?></h3>
                                <div class="wc-subtitle-6f187485">High-Performance Analyzer</div>
                                <div class="wc-desc-6f187485">
                                    <?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?>
                                </div>

                                <!-- Pricing -->
                                <div class="wc-price-container-6f187485">
                                    <?php if ( $product->is_on_sale() ) : ?>
                                        <span class="wc-price-sale-6f187485"><?php echo wc_price( $product->get_price() ); ?></span>
                                        <span class="wc-price-reg-6f187485"><?php echo wc_price( $regular_price ); ?></span>
                                        <span class="wc-save-badge-6f187485">Save <?php echo wc_price( $savings ); ?></span>
                                    <?php else : ?>
                                        <span class="wc-price-sale-6f187485"><?php echo wc_price( $product->get_price() ); ?></span>
                                    <?php endif; ?>
                                </div>

                                <!-- Actions -->
                                <div class="wc-actions-6f187485">
                                    <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="wc-btn-primary-6f187485">
                                        <?php echo esc_html( $product->single_add_to_cart_text() ? $product->single_add_to_cart_text() : 'Add to Cart' ); ?>
                                    </a>
                                    <a href="<?php the_permalink(); ?>" class="wc-btn-outline-6f187485">Full Specifications</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
            
            <!-- Navigation Arrows -->
            <div class="swiper-button-next swiper-nav-6f187485"></div>
            <div class="swiper-button-prev swiper-nav-6f187485"></div>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <div class="woo-carousel-wrapper-6f187485">
            <p style="text-align:center; padding: 20px; background: #f9f9f9; border: 1px dashed #ccc;">
                [Custom WooCommerce Product Carousel Preview]
            </p>
        </div>
        <?php
    }
}
