<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

const WOO_CAROUSEL_ASSETS_VERSION_6f187485 = '1.0.0';

function register_woo_carousel_widget_6f187485( $widgets_manager ) {
    require_once __DIR__ . '/widget-woo-carousel.php';
    $widgets_manager->register( new \AngieSnippets\Woo_Carousel_6f187485() );
}
add_action( 'elementor/widgets/register', 'register_woo_carousel_widget_6f187485' );

function register_woo_carousel_assets_6f187485() {
	wp_register_script( 'woo-carousel-script-6f187485', angie_cs_get_snippet_asset_url( __FILE__, 'script.js' ), [ 'elementor-frontend', 'swiper' ], WOO_CAROUSEL_ASSETS_VERSION_6f187485, true );
	wp_register_style( 'woo-carousel-style-6f187485', angie_cs_get_snippet_asset_url( __FILE__, 'style.css' ), [], WOO_CAROUSEL_ASSETS_VERSION_6f187485 );
}
add_action( 'wp_enqueue_scripts', 'register_woo_carousel_assets_6f187485' );
