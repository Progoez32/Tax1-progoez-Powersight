<?php
if (!defined('ABSPATH')) exit;
$file = ABSPATH . 'wp-content/novamira-sandbox/sec_accum.json';
if (file_exists($file)) @unlink($file);
$secs = array();
// Section 1 (hb5jl9i3)
$b_1 = '';
$b_1 .= 'eyJpZCI6ICJoYjVqbDlpMyIsICJlbFR5cGUiOiAiY29udGFpbmVyIiwgImlzSW5uZXIiOiBmYWxzZSwgInNldHRpbmdzIjogeyJjb250ZW50X3dpZHRoIjogImZ1bGwiLCAicGFkZGluZyI6IHsidW5pdCI6ICJweCIsICJ0b3AiOiAiMCIsICJyaWdodCI6ICIwIiwgImJvdHRvbSI6ICIwIiwgImxlZnQiOiAiMCJ9fSwgImVsZW1lbnRzIjogW3siaWQiOiAibXp6dTc2OTAiLCAiZWxUeXBlIjogIndp';
$b_1 .= 'ZGdldCIsICJ3aWRnZXRUeXBlIjogImh0bWwiLCAic2V0dGluZ3MiOiB7Imh0bWwiOiAiPHN0eWxlPlxuQGltcG9ydCB1cmwoJ2h0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9SW50ZXI6d2dodEA0MDA7NTAwOzYwMDs3MDA7ODAwJmRpc3BsYXk9c3dhcCcpO1xuXG5ib2R5LCAuZWxlbWVudG9yLXBhZ2Uge1xuICBmb250LWZhbWlseTogJ0ludGVyJywgc2Fucy1zZXJpZiAh';
$b_1 .= 'aW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMEQwRTEwICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG59XG5cbmgxLCBoMiwgaDMsIGg0LCBoNSwgaDYgeyBmb250LWZhbWlseTogJ0ludGVyJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50OyBsZXR0ZXItc3BhY2luZzogLTAuMDJlbSAhaW1wb3J0YW50OyB9XG5hIHsgdGV4dC1kZWNvcmF0aW9uOiBub25lICFp';
$b_1 .= 'bXBvcnRhbnQ7IHRyYW5zaXRpb246IGFsbCAwLjI1cyBlYXNlICFpbXBvcnRhbnQ7IH1cblxuLyogTWFycXVlZSBUcmFjayAqL1xuQGtleWZyYW1lcyBtYXJxdWVlU2Nyb2xsIHtcbiAgMCUgeyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7IH1cbiAgMTAwJSB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTsgfVxufVxuLm1hcnF1ZWUtdHJhY2sgeyBkaXNwbGF5OiBmbGV4OyBvdmVyZmxvdzog';
$b_1 .= 'aGlkZGVuOyB3aWR0aDogMTAwJTsgd2hpdGUtc3BhY2U6IG5vd3JhcDsgfVxuLm1hcnF1ZWUtY29udGVudCB7IGRpc3BsYXk6IGZsZXg7IGdhcDogNDhweDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgYW5pbWF0aW9uOiBtYXJxdWVlU2Nyb2xsIDI1cyBsaW5lYXIgaW5maW5pdGU7IH1cblxuLyogQ2F0ZWdvcnkgQ2FyZHMgSG92ZXIgKi9cbi5lbGVtZW50b3ItZWxlbWVudC5jYXQtY2FyZC1ib3gge1xu';
$b_1 .= 'ICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlICFpbXBvcnRhbnQ7XG59XG4uZWxlbWVudG9yLWVsZW1lbnQuY2F0LWNhcmQtYm94OmhvdmVyIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC02cHgpICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1jb2xvcjogIzlDMjMyNyAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiAwIDEycHggMjhweCByZ2JhKDE1NiwzNSwzOSwwLjE1KSAhaW1wb3J0YW50O1xu';
$b_1 .= 'fVxuXG4vKiBJbmR1c3RyeSBDYXJkcyBIb3ZlciAqL1xuLmVsZW1lbnRvci1lbGVtZW50LmluZC1jYXJkLWJveCB7XG4gIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UgIWltcG9ydGFudDtcbn1cbi5lbGVtZW50b3ItZWxlbWVudC5pbmQtY2FyZC1ib3g6aG92ZXIge1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTRweCkgIWltcG9ydGFudDtcbiAgYm9yZGVyLWNvbG9yOiAjOUMyMzI3ICFpbXBv';
$b_1 .= 'cnRhbnQ7XG59XG48L3N0eWxlPlxuIn19XX0=';
$json_raw_1 = base64_decode($b_1);
$json_fixed_1 = str_replace(array("\r", "\n", "\t"), array('\\r', '\\n', '\\t'), $json_raw_1);
$arr_1 = json_decode($json_fixed_1, true);
if ($arr_1) $secs[] = $arr_1;
file_put_contents($file, json_encode($secs));
return ['success' => true, 'sec' => 1, 'total_secs' => count($secs)];
